package org.testng.eclipse.util;

import org.testng.IReporter;

public abstract class ReporterListenerContributor implements IReporter
{
}
