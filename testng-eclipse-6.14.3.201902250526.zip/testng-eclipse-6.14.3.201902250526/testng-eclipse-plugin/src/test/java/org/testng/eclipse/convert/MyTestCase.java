package org.testng.eclipse.convert;

import junit.framework.TestCase;

public class MyTestCase extends TestCase {

  public MyTestCase(String name) {
    super(name);
  }

  public void assertMyStuff(Object o) {}

  protected void assert_notification_that(int i, int j) {
  }
}
