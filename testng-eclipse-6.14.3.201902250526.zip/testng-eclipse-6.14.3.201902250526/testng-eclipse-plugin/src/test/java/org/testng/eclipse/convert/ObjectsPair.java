package org.testng.eclipse.convert;

public class ObjectsPair {

  public static Pair<Double, Double> of(Double valueOf, Double valueOf2) {
    // TODO Auto-generated method stub
    return null;
  }

  public static Pair<Integer, Long> of(Integer valueOf, Long valueOf2) {
    // TODO Auto-generated method stub
    return null;
  }

  public static Pair<Double, Integer> of(Object valueOf, Integer valueOf2) {
    // TODO Auto-generated method stub
    return null;
  }

}
